import java.util.Comparator;

public class Point implements Comparable<Point> {

    // compare points by slope
    public final Comparator<Point> SLOPE_ORDER;       // YOUR DEFINITION HERE

    private final int x;                              // x coordinate
    private final int y;                              // y coordinate

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void draw() {
        StdDraw.point(x, y);
    }

    public void drawTo(Point that) {
        StdDraw.line(this.x, this.y, that.x, that.y);
    }

    public double slopeTo(Point that) {
        if (that.x == this.x && that.y == this.y) return -1000000;
        if (that.y == this.y) return 0;
        if (that.x == this.x) return 1000000;
        return (that.y - this.y) / (that.x - this.x);
    }

    public int compareTo(Point that) {
        if (this.x == that.x && this.y == that.y) return 0;
        if (this.y < that.y || (this.y == that.y && this.x < that.x)) {
            return -1;
        } else {
            return 1;
        }
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    private class Comparator<Point> {
        public int compare() {
            return 0;
        }
        public boolean equals() {
            return true;
        }
    }
}