/**
 * Created by Aygul on 03.03.2015.
 */
public class PatternRecognition {
    public static void main(String[] arrArgs) {

    }
}
