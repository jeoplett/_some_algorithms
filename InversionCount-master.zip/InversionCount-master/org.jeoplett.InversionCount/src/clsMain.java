import org.jeoplett.clsInversionCount;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class clsMain {

    public static Long[] arrInversions;

    public static void fncInitializeInversionArray() throws Exception {
        Integer intCount;
        Integer intArraySize;
        BufferedReader rdrFile;
        intArraySize = 0;
        try {
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream("C:\\Users\\aygul\\IdeaProjects\\InversionCount\\IntegerArray.txt")));
            while (rdrFile.readLine() != null) {
                intArraySize++;
            }
            rdrFile.close();
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream("C:\\Users\\aygul\\IdeaProjects\\InversionCount\\IntegerArray.txt")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw e;
        }
        arrInversions = new Long[intArraySize];
        for (intCount = 0; intCount <= arrInversions.length - 1; intCount++) {
            arrInversions[intCount] = new Long(rdrFile.readLine());
        }

    }

    public static void main (String[] arrArguments) {
        Long lngInversionCount;
        try {
            fncInitializeInversionArray();
        } catch (Exception e) {
            return;
        }
        clsInversionCount objInversionCount = new clsInversionCount();
        lngInversionCount = objInversionCount.fncCountInversions(arrInversions);
        System.out.println(lngInversionCount);
    }

}
