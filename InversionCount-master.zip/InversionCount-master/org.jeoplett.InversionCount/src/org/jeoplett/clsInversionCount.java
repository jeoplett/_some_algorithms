package org.jeoplett;

public class clsInversionCount {

    private Long[] arrArray = new Long[1];
    private Long[] arrHelpArray = new Long[1];

    public clsInversionCount() {
    }

    private void fncCloneArray(Long[] arrInputArray) {
        Integer intCount;
        this.arrArray = new Long[arrInputArray.length];
        this.arrHelpArray = new Long[arrInputArray.length];
        for (intCount = 0; intCount <= arrInputArray.length - 1; intCount ++) {
            this.arrArray[intCount] = arrInputArray[intCount];
        }
    }

    private Long fncRecursiveCountInversions(Integer intBegin, Integer intEnd) {
        Long lngExchange, lngInversionCount;
        Integer intCounta, intCountb, intMiddle, intCount;
        // Base case: when we have only 1 element in array
        if (intBegin >= intEnd) { return new Long(0); }
        // Recursion: divide array onto 2 arrays and do it again
        lngInversionCount = fncRecursiveCountInversions(intBegin, intBegin + new Double((intEnd - intBegin)/2).intValue()) + fncRecursiveCountInversions(intBegin + new Double((intEnd - intBegin)/2).intValue() + 1, intEnd);
        // Tail: merge the result
        for (intCounta = intBegin; intCounta <= intEnd; intCounta++) {
            this.arrHelpArray[intCounta] = this.arrArray[intCounta];
        }
        intMiddle = intBegin + new Double((intEnd - intBegin)/2).intValue();
        intCountb = intMiddle + 1;
        for (intCounta = intBegin; intCounta + intCountb - intMiddle <= intEnd; intCounta = intCounta) {
            if (this.arrHelpArray[intCounta] > this.arrHelpArray[intCountb]) {
                lngInversionCount += intMiddle - intCounta + 1;
                this.arrArray[intCounta + intCountb - intMiddle - 1] = this.arrHelpArray[intCountb];
                intCountb++;
            } else {
                this.arrArray[intCounta + intCountb - intMiddle - 1] = this.arrHelpArray[intCounta];
                intCounta++;
            }
            if (intCountb > intEnd) {
                for (intCount = intCounta; intCount <= intMiddle; intCount++) {
                    this.arrArray[intCount + intCountb - intMiddle - 1] = this.arrHelpArray[intCount];
                }
                break;
            }
            if (intCounta > intMiddle) {
                break;
            }
        }
        return lngInversionCount;
    }

    public Long fncCountInversions(Long[] arrInputArray) {
        Long lngInversionCount;
        if (arrInputArray.length <= 1) { return new Long(0); }
        if (this.arrArray.length != arrInputArray.length) { this.fncCloneArray(arrInputArray); }
        lngInversionCount = fncRecursiveCountInversions(0, this.arrArray.length - 1);
        return lngInversionCount;
    }

}
