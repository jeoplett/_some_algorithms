import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class QuickSort {

    public int[] arrArray;
    public int intComparisonsCount;

    public QuickSort() {
    }

    private void fncInitializeArray(String strFileName) throws Exception {
        Integer intCount;
        Integer intArraySize;
        BufferedReader rdrFile;
        intArraySize = 0;
        try {
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream(strFileName)));
            while (rdrFile.readLine() != null) {
                intArraySize++;
            }
            rdrFile.close();
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream(strFileName)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw e;
        }
        this.arrArray = new int[intArraySize];
        for (intCount = 0; intCount <= this.arrArray.length - 1; intCount++) {
            this.arrArray[intCount] = Integer.parseInt(rdrFile.readLine());
        }
    }

    private int fncPartition (int start, int end)
    {
        //int marker = start;
        //for ( int i = start; i <= end; i++ ) {
        //    if ( this.arrArray[i] <= this.arrArray[end] ) {
        //        int temp = this.arrArray[marker]; // swap
        //        this.arrArray[marker] = this.arrArray[i];
        //        this.arrArray[i] = temp;
        //        marker += 1;
        //    }
        //}
        //return marker - 1;

        int intCounta, intCountb, intSwap;
        int a, b, c;
        int intPartElem = this.arrArray[start];

        //intSwap = this.arrArray[end];
        //this.arrArray[end] = this.arrArray[start];
        //this.arrArray[start] = intSwap;

        a = this.arrArray[start];
        b = this.arrArray[end];
        c = this.arrArray[start + new Integer((end - start)/2).intValue()];

        if ( (c >= a && a >=b) || (b >= a && a >=c) ) { intPartElem = start; }
        if ( (a >= c && c >=b) || (b >= c && c >=a) ) { intPartElem = start + new Integer((end - start)/2).intValue(); }
        if ( (c >= b && b >=a) || (a >= b && b >=c) ) { intPartElem = end; }

        intSwap = this.arrArray[start];
        this.arrArray[start] = this.arrArray[intPartElem];
        this.arrArray[intPartElem] = intSwap;

        intPartElem = this.arrArray[start];
        intCounta = start + 1;
        for (intCountb = start + 1; intCountb <= end; intCountb++) {
            if (this.arrArray[intCountb] < intPartElem) {
                intSwap = this.arrArray[intCounta];
                this.arrArray[intCounta] = this.arrArray[intCountb];
                this.arrArray[intCountb] = intSwap;
                intCounta++;
            }
        }
        intSwap = this.arrArray[start];
        this.arrArray[start] = this.arrArray[intCounta - 1];
        this.arrArray[intCounta - 1] = intSwap;
        return intCounta - 1;
    }

    private void fncRecursiveSort (int start, int end)
    {
        if ( start >= end ) {
            return;
        }
        int pivot = this.fncPartition(start, end);
        this.fncRecursiveSort(start, pivot - 1);
        if (pivot - 1 > start) { this.intComparisonsCount += (pivot - 1) - start; }
        this.fncRecursiveSort(pivot + 1, end);
        if (end > pivot + 1) { this.intComparisonsCount += end - (pivot + 1); }
    }

    public int fncSort() {
        this.intComparisonsCount = this.arrArray.length - 1;
        this.fncRecursiveSort(0, this.arrArray.length - 1);
        return this.intComparisonsCount;
    }

    public static void main(String[] args) throws Exception {
        QuickSort objOperator = new QuickSort();
        objOperator.fncInitializeArray("C:\\Users\\Aygul\\IdeaProjects\\QuickSort\\IntegerArray.txt");
        System.out.println(objOperator.fncSort());
    }
}
