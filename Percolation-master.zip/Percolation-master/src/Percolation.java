
public class Percolation {
    private WeightedQuickUnionUF objOperator;
    private int[] arrStates;
    private int N;
    private boolean blnIsPercolated;

    public Percolation(int N) throws Exception {
        int intCount;
        if (N <= 0) { throw new IllegalArgumentException("The size of the matrix should be larger than or equal to 1"); }
        this.N = N;
        this.blnIsPercolated = false;
        this.objOperator = new WeightedQuickUnionUF(N*N);
        this.arrStates = new int[N*N];
        for (intCount = 0; intCount <= this.N - 1; intCount++) { this.arrStates[intCount] = 0; }
        return;
    }

    public void open(int i, int j) throws Exception {
        int intState;
        if ( this.isOpen(i, j) ) { return; }
        intState = 1;
        if ((i <= 0 || i > this.N) || (j <= 0 || j > this.N)) { throw new IndexOutOfBoundsException("Index values should be between 1 and " + this.N); }
        if ((i > 1) && this.isOpen(i - 1, j)) { intState = intState | this.arrStates[this.objOperator.find(((i - 2)*this.N + j) - 1)]; this.objOperator.union(((i - 1)*this.N + j) - 1, ((i - 2)*this.N + j) - 1); }
        if ((i < this.N) && this.isOpen(i + 1, j)) { intState = intState | this.arrStates[this.objOperator.find((i*this.N + j) - 1)]; this.objOperator.union(((i - 1)*this.N + j) - 1, (i*this.N + j) - 1); }
        if ((j > 1) && this.isOpen(i, j - 1)) { intState = intState | this.arrStates[this.objOperator.find(((i - 1)*this.N + (j - 1)) - 1)]; this.objOperator.union(((i - 1)*this.N + j) - 1, ((i - 1)*this.N + (j - 1)) - 1); }
        if ((j < this.N) && this.isOpen(i, j + 1)) { intState = intState | this.arrStates[this.objOperator.find(((i - 1)*this.N + (j + 1)) - 1)]; this.objOperator.union(((i - 1)*this.N + j) - 1, ((i - 1)*this.N + (j + 1)) - 1); }
        if (i == 1) { intState = intState | 2; }
        if (i == this.N) { intState = intState | 4; }
        if ( intState >= 6) { this.blnIsPercolated = true; }
        this.arrStates[this.objOperator.find(((i - 1)*this.N + j) - 1)] = intState;
        this.arrStates[((i - 1)*this.N + j) - 1] = intState;
        return;
    }

    public boolean isOpen(int i, int j) throws Exception {
        if ((i <= 0 || i > this.N) || (j <= 0 || j > this.N)) { throw new IndexOutOfBoundsException("Index values should be between 1 and " + this.N); }
        return this.arrStates[((i - 1)*this.N + j) - 1] > 0;
    }

    public boolean isFull(int i, int j) throws Exception {
        if ((i <= 0 || i > this.N) || (j <= 0 || j > this.N)) { throw new IndexOutOfBoundsException("Index values should be between 1 and " + this.N); }
        return (this.arrStates[this.objOperator.find(((i - 1)*this.N + j) - 1)] & 2) > 0;
    }

    public boolean percolates() {
        return this.blnIsPercolated;
    }
}
