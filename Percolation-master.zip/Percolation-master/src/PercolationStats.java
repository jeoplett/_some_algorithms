
public class PercolationStats {
    private int N, T;
    private Percolation objOperator;
    private double[] arrResults;

    public PercolationStats(int N, int T) throws Exception {
        if ((N <= 0 || T <= 0)) { throw new IllegalArgumentException("Index values should integer > 0"); }
        this.N = N;
        this.T = T;
        this.arrResults = new double[T];
        int intCount, intCounta;
        int i, j;
        for (intCount = 0; intCount <= T - 1; intCount++) {
            this.objOperator = null;
            this.objOperator = new Percolation(N);
            intCounta = 0;
            while ( !this.objOperator.percolates() ) {
                i = StdRandom.uniform(1, N + 1);
                j = StdRandom.uniform(1, N + 1);
                if ( !this.objOperator.isOpen(i, j) ) {
                    this.objOperator.open(i, j);
                    intCounta++;
                }
            }
            this.arrResults[intCount] = (double) intCounta / (this.N*this.N);
        }
        StdOut.print("mean \t\t\t = ");
        StdOut.println( this.mean() );
        StdOut.print("stddev \t\t\t = ");
        StdOut.println( this.stddev() );
        StdOut.print("95% confidence interval  = ");
        StdOut.print( this.confidenceLo() );
        StdOut.print(", ");
        StdOut.print(  this.confidenceHi() );
    }
    public double mean() {
        return StdStats.mean(this.arrResults);
    }
    public double stddev() {
        return StdStats.stddev(this.arrResults);
    }
    public double confidenceLo() {
        return StdStats.mean(this.arrResults) - 1.96 * StdStats.stddev(this.arrResults) / java.lang.Math.sqrt(this.T);
    }
    public double confidenceHi() {
        return StdStats.mean(this.arrResults) + 1.96 * StdStats.stddev(this.arrResults) / java.lang.Math.sqrt(this.T);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) { throw new Exception("Provide 2 arguments: 1st - the size of matrix and 2nd - the number of tests."); }
        PercolationStats objDo = new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        objDo = null;
    }
}