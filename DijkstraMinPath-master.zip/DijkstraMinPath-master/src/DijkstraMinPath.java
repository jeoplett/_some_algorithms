/**
 * Created by Aygul on 28.02.2015.
 */

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Map;

public class DijkstraMinPath {
    public static void main(String[] arrArguments) throws Exception {
        DirectedGraph<Integer> grpDirectedGraph = new DirectedGraph<Integer>();
        Dijkstra algOperator = new Dijkstra();
        Integer intCount, intCounta;
        Integer intArraySize;
        String strLine;
        BufferedReader rdrFile;
        intArraySize = 0;
        try {
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream("C:\\Users\\Aygul\\IdeaProjects\\DijkstraMinPath\\src\\dijkstraData.txt")));
            while (rdrFile.readLine() != null) {
                grpDirectedGraph.addNode(intArraySize + 1);
                intArraySize++;
            }
            rdrFile.close();
            rdrFile = new BufferedReader( new InputStreamReader( new FileInputStream("C:\\Users\\Aygul\\IdeaProjects\\DijkstraMinPath\\src\\dijkstraData.txt")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw e;
        }
        for (intCount = 0; intCount <= intArraySize - 1; intCount++) {
            strLine = rdrFile.readLine();
            String[] arrStringElements = strLine.split("\t");
            for (intCounta = 1; intCounta <= arrStringElements.length - 1; intCounta++) {
                grpDirectedGraph.addEdge(Integer.parseInt(arrStringElements[0]), Integer.parseInt(arrStringElements[intCounta].split(",")[0]), Integer.parseInt(arrStringElements[intCounta].split(",")[1]));
            }
        }
        Map<Integer, Double> mapMap = algOperator.shortestPaths(grpDirectedGraph, 1);
    }
}
