import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private LinkedList<Item> lstFirstLinkedListItem;
    private LinkedList<Item> lstLastLinkedListItem;
    private int intLinkedListSize = 0;

    public Deque() {
    }

    public boolean isEmpty() {
        return this.intLinkedListSize == 0;
    }
    public int size() {
        return this.intLinkedListSize;
    }
    public void addFirst(Item itmNewFirstItem) throws Exception {
        if (itmNewFirstItem == null) { throw new NullPointerException("Element of the linked list can't be null."); }
        LinkedList<Item> lstNewFirstItem = new LinkedList<Item>();
        lstNewFirstItem.itmItem = itmNewFirstItem;
        if (this.intLinkedListSize == 0) {
            this.lstLastLinkedListItem = lstNewFirstItem;
            this.lstFirstLinkedListItem = lstNewFirstItem;
            this.intLinkedListSize++;
            return;
        }
        this.lstFirstLinkedListItem.lstPrevious = lstNewFirstItem;
        lstNewFirstItem.lstNext = this.lstFirstLinkedListItem;
        this.lstFirstLinkedListItem = lstNewFirstItem;
        this.intLinkedListSize++;
    }
    public void addLast(Item itmNewLastItem) {
        if (itmNewLastItem == null) { throw new NullPointerException("Element of the linked list can't be null."); }
        LinkedList<Item> lstNewLastItem = new LinkedList<Item>();
        lstNewLastItem.itmItem = itmNewLastItem;
        if (this.intLinkedListSize == 0) {
            this.lstLastLinkedListItem = lstNewLastItem;
            this.lstFirstLinkedListItem = lstNewLastItem;
            this.intLinkedListSize++;
            return;
        }
        lstNewLastItem.lstPrevious = this.lstLastLinkedListItem;
        this.lstLastLinkedListItem.lstNext = lstNewLastItem;
        this.lstLastLinkedListItem = lstNewLastItem;
        this.intLinkedListSize++;
    }
    public Item removeFirst() throws Exception {
        if (this.intLinkedListSize <= 0) { throw new NoSuchElementException("The linked list is empty."); }
        Item itmCurrentFirstItem = this.lstFirstLinkedListItem.itmItem;
        this.lstFirstLinkedListItem = this.lstFirstLinkedListItem.lstNext;
        this.intLinkedListSize--;
        if (this.intLinkedListSize == 1) { this.lstFirstLinkedListItem = this.lstLastLinkedListItem; }
        return itmCurrentFirstItem;
    }
    public Item removeLast() {
        if (this.intLinkedListSize <= 0) { throw new NoSuchElementException("The linked list is empty."); }
        Item itmCurrentLastItem = this.lstLastLinkedListItem.itmItem;
        this.lstLastLinkedListItem = this.lstLastLinkedListItem.lstPrevious;
        this.intLinkedListSize--;
        if (this.intLinkedListSize == 1) { this.lstLastLinkedListItem = this.lstFirstLinkedListItem; }
        return itmCurrentLastItem;
    }

    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        LinkedList<Item> lstIterator = lstFirstLinkedListItem;
        public boolean hasNext() { return lstIterator != null; }
        public Item next() {
            if (lstIterator == null) { throw new NoSuchElementException("There are no more elements in the linked list."); }
            Item itmCurrentItem = lstIterator.itmItem;
            this.lstIterator = this.lstIterator.lstNext;
            return itmCurrentItem;
        }
        public void remove() throws UnsupportedOperationException { throw new UnsupportedOperationException("This operation is not supported by this Iterator implementation."); }
    }

    private class LinkedList<Item> {
        public Item itmItem;
        public LinkedList<Item> lstNext;
        public LinkedList<Item> lstPrevious;
    }

    public static void main(String[] args) throws Exception {
        Deque<String> dquDeque = new Deque<String>();
        dquDeque.addFirst("1");
        dquDeque.addLast("2");
        for (String strItem : dquDeque) {
            System.out.println(strItem);
        }
        System.out.println(dquDeque.size());
        System.out.println(dquDeque.removeFirst());
        System.out.println(dquDeque.size());
        System.out.println(dquDeque.removeLast());
        System.out.println(dquDeque.size());
        System.out.println(dquDeque.removeFirst());
        System.out.println(dquDeque.removeLast());
    }
}
