import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private Item[] arrItems;
    private int intQueSize;

    public RandomizedQueue() {
        this.intQueSize = 0;
        this.arrItems = (Item[]) new Object[2];
    }

    public boolean isEmpty() {
        return this.intQueSize == 0;
    }
    public int size(){
        return this.intQueSize;
    }
    public void enqueue(Item itmItem) throws Exception {
        if(itmItem == null) { throw new NullPointerException("Can't enqueue null."); }
        if (this.intQueSize + 1 <= this.arrItems.length) { this.resize(this.arrItems.length * 2);}
        this.arrItems[this.intQueSize] = itmItem;
        this.intQueSize++;
    }
    public Item dequeue() throws Exception {
        if (this.intQueSize == 0) { throw new NoSuchElementException("Que is empty."); }
        if (this.intQueSize < this.arrItems.length / 4) { this.resize(this.arrItems.length / 2);}
        int intNumber;
        Item itmItem;
        intNumber = StdRandom.uniform(0, this.intQueSize);
        itmItem = this.arrItems[intNumber];
        this.arrItems[intNumber] = this.arrItems[this.intQueSize - 1];
        this.intQueSize--;
        return itmItem;
    }
    public Item sample() throws Exception {
        if (this.intQueSize == 0) { throw new NoSuchElementException("Que is empty."); }
        int intNumber;
        intNumber = StdRandom.uniform(0, this.intQueSize);
        return this.arrItems[intNumber];
    }
    private void resize(int intNewSize) {
        Item[] arrNewArray = (Item[]) new Object[intNewSize];
        int intCount;
        for (intCount = 0; intCount <= intNewSize - 1; intCount++) {
            arrNewArray[intCount] = this.arrItems[intCount];
        }
        this.arrItems = arrNewArray;
    }
    public Iterator<Item> iterator() {
        return new RandomizedQueIterator();
    }
    private class RandomizedQueIterator implements Iterator<Item> {
        int[] arrNumeration;
        int intCurrentNumber = 0;
        public RandomizedQueIterator() {
            int intCount;
            this.arrNumeration = new int[intQueSize];
            for (intCount = 0; intCount <= intQueSize - 1; intCount++) {
                this.arrNumeration[intCount] = intCount;
            }
            StdRandom.shuffle(this.arrNumeration);
        }
        public boolean hasNext() {
            return intCurrentNumber != intQueSize;
        }
        public Item next() throws NoSuchElementException {
            if (this.intCurrentNumber == intQueSize) { throw new NoSuchElementException("Que is empty."); }
            int intCurrentNumber;
            intCurrentNumber = this.intCurrentNumber;
            this.intCurrentNumber++;
            return arrItems[this.arrNumeration[intCurrentNumber]];
        }
        public void remove() throws UnsupportedOperationException { throw new UnsupportedOperationException("This operation is not supported by this Iterator implementation."); }
    }
    public static void main(String[] args) {

    }
}